import { useEffect, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { Flower2, Heart, Music2, Music4, Sparkles, Volume2, VolumeX } from 'lucide-react'

type Petal = {
  id: number
  left: number
  delay: number
  duration: number
  size: number
  drift: number
}

const petals: Petal[] = Array.from({ length: 22 }, (_, index) => ({
  id: index,
  left: (index * 37 + 7) % 100,
  delay: (index % 11) * -1.7,
  duration: 11 + (index % 7) * 2,
  size: 9 + (index % 5) * 3,
  drift: (index % 2 === 0 ? 1 : -1) * (20 + (index % 5) * 12),
}))

function App() {
  const [letterOpen, setLetterOpen] = useState(false)
  const [musicOn, setMusicOn] = useState(false)
  const [showSurprise, setShowSurprise] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    if (musicOn) {
      void audio.play().catch(() => setMusicOn(false))
    } else {
      audio.pause()
    }
  }, [musicOn])

  const toggleMusic = () => setMusicOn((current) => !current)

  return (
    <main className="page-shell">
      <div className="ambient ambient-one" aria-hidden="true" />
      <div className="ambient ambient-two" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />

      <div className="petal-field" aria-hidden="true">
        {petals.map((petal) => (
          <span
            className="falling-petal"
            key={petal.id}
            style={{
              '--left': `${petal.left}%`,
              '--delay': `${petal.delay}s`,
              '--duration': `${petal.duration}s`,
              '--size': `${petal.size}px`,
              '--drift': `${petal.drift}px`,
            } as CSSProperties}
          />
        ))}
      </div>

      <header className="topbar">
        <a className="brand" href="#home" aria-label="Về đầu trang">
          <span className="brand-mark"><Flower2 size={18} strokeWidth={1.7} /></span>
          <span>dear, you<span className="brand-dot">.</span></span>
        </a>
        <button
          className={`music-button ${musicOn ? 'is-playing' : ''}`}
          onClick={toggleMusic}
          aria-pressed={musicOn}
        >
          {musicOn ? <Volume2 size={16} /> : <Music2 size={16} />}
          <span>{musicOn ? 'Đang phát nhạc' : 'Bật nhạc'}</span>
          {musicOn && <span className="sound-bars" aria-hidden="true"><i /><i /><i /></span>}
        </button>
      </header>

      <section className="hero" id="home">
        <div className="eyebrow"><Sparkles size={14} /> A LITTLE NOTE FOR YOU</div>
        <h1>Gửi những điều<br /><em>dịu dàng nhất</em></h1>
        <p className="hero-copy">
          Nhân một ngày thật đặc biệt, mong rằng thế giới sẽ dịu dàng với bạn
          như cách bạn làm những người xung quanh mỉm cười.
        </p>

        <div className="bouquet-wrap" aria-label="Bó hoa hồng minh họa">
          <div className="bouquet-glow" />
          <div className="flower flower-back flower-back-left">
            <span className="stem" /><span className="leaf leaf-left" /><span className="leaf leaf-right" />
            <span className="bloom bloom-pink"><i /><i /><i /><i /><i /><i /><b /></span>
          </div>
          <div className="flower flower-back flower-back-right">
            <span className="stem" /><span className="leaf leaf-left" /><span className="leaf leaf-right" />
            <span className="bloom bloom-cream"><i /><i /><i /><i /><i /><i /><b /></span>
          </div>
          <div className="flower flower-main">
            <span className="stem" /><span className="leaf leaf-left" /><span className="leaf leaf-right" />
            <span className="bloom bloom-rose"><i /><i /><i /><i /><i /><i /><b /></span>
          </div>
          <div className="flower flower-side flower-side-left">
            <span className="stem" /><span className="leaf leaf-left" />
            <span className="bloom bloom-peach"><i /><i /><i /><i /><i /><b /></span>
          </div>
          <div className="flower flower-side flower-side-right">
            <span className="stem" /><span className="leaf leaf-right" />
            <span className="bloom bloom-blush"><i /><i /><i /><i /><i /><b /></span>
          </div>
          <div className="bouquet-wrap-ribbon"><span /></div>
          <span className="floating-heart heart-a"><Heart size={15} fill="currentColor" /></span>
          <span className="floating-heart heart-b"><Heart size={10} fill="currentColor" /></span>
          <span className="sparkle sparkle-a">✦</span>
          <span className="sparkle sparkle-b">✧</span>
          <span className="sparkle sparkle-c">✦</span>
        </div>

        <div className="date-stamp">
          <span className="date-line" />
          <span>THÁNG MƯỜI · NGÀY HAI MƯƠI</span>
          <span className="date-line" />
        </div>
        <div className="occasion">Happy Vietnamese Women’s Day</div>

        <button className="primary-button" onClick={() => setLetterOpen(true)}>
          <span>Mở lá thư dành cho bạn</span>
          <Heart size={16} />
        </button>
        <p className="tiny-note">được viết bằng một chút yêu thương ♡</p>
      </section>

      <section className="wish-strip" aria-label="Lời chúc">
        <div className="wish-item"><span className="wish-icon">✿</span><span>Luôn xinh đẹp theo cách của riêng mình</span></div>
        <span className="wish-divider" />
        <div className="wish-item"><span className="wish-icon">♡</span><span>Luôn được yêu thương và trân trọng</span></div>
        <span className="wish-divider" />
        <div className="wish-item"><span className="wish-icon">☼</span><span>Luôn tìm thấy niềm vui mỗi ngày</span></div>
      </section>

      <footer className="footer">
        <span>MADE WITH <Heart size={11} fill="currentColor" /> FOR YOU</span>
        <span className="footer-date">20 · 10</span>
      </footer>

      {letterOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget) setLetterOpen(false)
        }}>
          <section className="letter-modal" role="dialog" aria-modal="true" aria-labelledby="letter-title">
            <button className="close-button" onClick={() => setLetterOpen(false)} aria-label="Đóng thư">×</button>
            <div className="letter-flower"><Flower2 size={28} strokeWidth={1.2} /></div>
            <p className="letter-kicker">A LETTER FOR YOU</p>
            <h2 id="letter-title">Gửi cô gái <em>tuyệt vời</em></h2>
            <div className="letter-body">
              <p>Chúc bạn có một ngày 20/10 thật vui vẻ và ngập tràn những điều ngọt ngào.</p>
              <p>Mong bạn luôn đủ tự tin để tỏa sáng, đủ mạnh mẽ để vượt qua những ngày không dễ dàng, và luôn nhớ rằng bản thân mình xứng đáng với những điều tốt đẹp.</p>
              <p>Hy vọng nụ cười sẽ ở lại thật lâu trên môi bạn, những ước mơ sẽ dần thành hiện thực, và mỗi ngày đều có một lý do nhỏ bé để bạn thấy hạnh phúc.</p>
            </div>
            <div className="letter-signoff">Thương chúc bạn thật nhiều ♡</div>
            <button className="surprise-button" onClick={() => setShowSurprise((value) => !value)}>
              {showSurprise ? 'Cất món quà nhỏ' : 'Một điều muốn nhắn gửi'} <Sparkles size={15} />
            </button>
            {showSurprise && (
              <p className="surprise-message">Đừng quên dành cho bản thân sự dịu dàng mà bạn vẫn luôn dành cho mọi người nhé. Bạn cũng xứng đáng được nâng niu. 🌷</p>
            )}
          </section>
        </div>
      )}

      <audio ref={audioRef} loop preload="none" src="/music.mp3" />
      <span className="sr-only" aria-live="polite">{musicOn ? 'Nhạc đang bật' : 'Nhạc đang tắt'}</span>
      <button className="floating-music" onClick={toggleMusic} aria-label={musicOn ? 'Tắt nhạc' : 'Bật nhạc'}>
        {musicOn ? <Music4 size={18} /> : <VolumeX size={18} />}
      </button>
    </main>
  )
}

export default App
